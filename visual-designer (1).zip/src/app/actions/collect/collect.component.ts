import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-collect',
  templateUrl: './collect.component.html',
  styleUrls: ['./collect.component.scss']
})
export class CollectComponent implements OnInit {

  @Input() item: any;

  model = {
    text: '',
    to: '',
    continueTo: null,
    from: '',
    statusCallback: ''
  };

  constructor() { }

  ngOnInit(): void {
    this.item.model = this.model;
  }

}
