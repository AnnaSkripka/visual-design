import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-record',
  templateUrl: './record.component.html',
  styleUrls: ['./record.component.scss']
})
export class RecordComponent implements OnInit {

  @Input() item: any;

  model = {
    continueTo: null,
    beep: '',
    timeout: '',
    maxLength: '',
    finishOn: 'any',
    customKey: ''
  };

  settingActive = false;

  constructor() { }

  ngOnInit(): void {
    this.item.model = this.model;
  }

}
