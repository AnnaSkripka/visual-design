import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-external-service',
  templateUrl: './external-service.component.html',
  styleUrls: ['./external-service.component.scss']
})
export class ExternalServiceComponent implements OnInit {

  @Input() item: any;

  model = {
    text: '',
    to: '',
    continueTo: null,
    from: '',
    statusCallback: ''
  };

  constructor() { }

  ngOnInit(): void {
    this.item.model = this.model;
  }

}
