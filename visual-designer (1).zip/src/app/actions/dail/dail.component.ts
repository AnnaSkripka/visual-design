import { Component, OnInit, NgZone, ChangeDetectorRef, Input, AfterViewInit, Host, HostListener } from '@angular/core';
import { lockupVarsList } from 'src/app/config';

declare var $: any;

@Component({
  selector: 'app-dail',
  templateUrl: './dail.component.html',
  styleUrls: ['./dail.component.scss']
})
export class DailComponent implements OnInit, AfterViewInit {

  @Input() item: any;

  defaults = {
    phone: { statusCallbackType: 'URL' },
    client: { statusCallbackType: 'URL' },
    conference: { whileWaitingType: 'URL' },
    'sip-url': { statusCallbackType: 'URL' }
  };

  get lockupVarsList() {
    return lockupVarsList;
  }

  model = {
    nouns: [],
    continueTo: '',
    timeout: null,
    timeLimit: null,
    callerID: null,
    beforeConnect: null,
    ringBackType: 'project',
    ringBack: null
  };

  setting1 = false;

  constructor(private cdRef: ChangeDetectorRef) { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    $('.dial-noun').draggable({
      revert: 'invalid',
      helper: 'clone',
      connectToSortable: '.dial-dropzone',
    });
    $('.dial-dropzone').sortable({
      handle: '.handle',
      placeholder: 'ui-state-highlight',
      over: (_, ui) => {
        $('.dial-dropzone .empty-dropzone').remove();
      },
      update: (_, ui) => {
        const item = ui.item;
        if (item.hasClass('dial-noun')) {
          const type = item.data('type');
          const index = item.index();
          this.model.nouns.splice(index, 0, { type, setting: false, ...this.defaults[type] });
          this.cdRef.detectChanges();
        }
        $('.dial-dropzone .dial-noun').remove();
      }
    });
    this.item.model = this.model;
  }

  remove(index) {
    this.model.nouns.splice(index, 1);
  }

  @HostListener('click')
  click() {
    setTimeout(_ => {
      this.cdRef.detectChanges();
    });
  }
}
