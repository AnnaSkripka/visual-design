import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-control',
  templateUrl: './control.component.html',
  styleUrls: ['./control.component.scss']
})
export class ControlComponent implements OnInit {

  @Input() item: any;

  model = {
    conditions: [],
    actions: []
  };

  constructor() { }

  ngOnInit(): void {
    this.item.model = this.model;
  }

  addCondition() {
    this.model.conditions.push({ condition: 'equal', regexType: 'regex', compareAs: 'text' });
  }

  addAction() {
    this.model.actions.push({ action: 'continue-to', varType: 'scope' });
  }

  onNeedleChange(condition) {
    switch (condition.regexType) {
      case 'regex':
        condition.pattern = condition.needle;
        break;
      case 'startsWith':
        condition.pattern = '^' + condition.needle + '.*';
        break;
      case 'endsWith':
        condition.pattern = '^.*' + condition.needle + '$';
        break;
      case 'contains':
        condition.pattern = '^.*' + condition.needle + '.*$';
        break;
    }
  }
}
