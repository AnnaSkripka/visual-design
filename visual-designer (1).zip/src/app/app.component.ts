import { Component, ViewChild, ElementRef, OnInit, AfterViewInit, NgZone, ChangeDetectorRef } from '@angular/core';

declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {

  leftItems = [
    { id: 'Play', icon: 'play-circle', text: 'Play' },
    { id: 'Say', icon: 'quote-left', text: 'Say' },
    { id: 'Collect', icon: 'th', text: 'Collect' },
    { id: 'Dial', icon: 'phone', text: 'Dial' },
    { id: 'HangUp', icon: 'times', text: 'Hang Up' },
    { id: 'Control', icon: 'cogs', text: 'Control' },
    { id: 'ExternalService', icon: 'external-link', text: 'External Service' },
    { id: 'Log', icon: 'align-justify', text: 'Log' },
    { id: 'Reject', icon: 'thumbs-o-down', text: 'Reject' },
    { id: 'Redirect', icon: 'link', text: 'Redirect' },
    { id: 'Pause', icon: 'pause', text: 'Pause' },
    { id: 'SMS', icon: 'envelope-o', text: 'SMS' },
    { id: 'Email', icon: 'comment-o', text: 'Email' },
    { id: 'Record', icon: 'microphone', text: 'Record' },
    { id: 'Print', icon: 'print', text: 'Print' }
  ];

  rightItems = [
    // { id: 'Dial', icon: 'phone', text: 'Dial' }
  ];

  constructor(private cdRef: ChangeDetectorRef) {
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    $('.draggable').draggable({
      revert: 'invalid',
      connectToSortable: '.sortable',
      helper: 'clone',
      start: (event, ui) => {
        $(ui.helper).addClass('ui-helper');
      }
    });
    $('.sortable').sortable({
      revert: true,
      handle: '.handle',
      placeholder: 'ui-state-highlight',
      receive: (event, ui) => {
      },
      update: (_, ui) => {
        const item = ui.item;
        if (item.hasClass('draggable')) {
          const id = item.data('id');
          const index = item.index();
          const _item = this.leftItems.find(x => x.id === id);
          this.rightItems.splice(index, 0, { ..._item });
        }
        $('.sortable .draggable').remove();
        this.cdRef.detectChanges();
      }
    });
  }

  removePanel(index: number) {
    this.rightItems.splice(index, 1);
  }

  save() {
    const data = [];
    this.rightItems.forEach(item => {
      data.push({ [item.text]: item['model'] });
    });
    ;
    const a = document.createElement('a');
    const file = new Blob([JSON.stringify(data)], {type: 'text'});
    a.href = URL.createObjectURL(file);
    a.download = 'data.json';
    a.click();
  }
}
